const { rimraf } = require('rimraf');

rimraf('./userData/binance')
  .then(() => {
    console.log('Deleted ./userData/binance');
  })
  .catch((err) => {
    console.error(`Error deleting directory: ${err}`);
  });