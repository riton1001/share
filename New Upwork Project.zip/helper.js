// helper.js

const delay = ms => new Promise(res => setTimeout(res, ms));

const randomRange = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

module.exports = {
    delay,
    randomRange
}
