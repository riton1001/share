//node prerequisites
const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const helper = require('./helper.js');
// const chromePath = "C:/Program Files/Google/Chrome/Application/chrome.exe"; //browser path for puppeteer
const chromePath = "C:/Program Files/BraveSoftware/Brave-Browser/Application/brave.exe"; //browser path for puppeteer
puppeteer.use(StealthPlugin()); //set unique fingerprints
const fs = require('fs-extra');
const emails = "./binance-emails.txt";
const results = "./results.txt";
const axios = require('axios');
const UserAgent = require('user-agents');
const ua = new UserAgent({ deviceCategory: "desktop" });
const newUserAgent = ua.userAgent;

const { rimraf } = require('rimraf');

const captchaRequest = "./captcha request.txt";

const path = require('path');


(async function () {

    const emailsList = await fs.readFileSync(emails).toString().split('\r\n');

    for await (email of emailsList) {
        // const proxyData = await getProxy(await helper.randomRange(0, 9));
        // const proxyData = await getProxy(await helper.randomRange(0, 49));
        const proxyData = await getProxy(await helper.randomRange(0, 24));

        var proxyip = await proxyData.proxy_address;
        var proxyport = proxyData.port;
        var proxyuser = proxyData.username;
        var proxypass = proxyData.password;
        let captchaRequired = false;

        console.log(proxyip);
        console.log(proxyport);

        // console.log(emailsList);

        try {
            rimraf('./userData/binance')
                .then(() => {
                    console.log('Deleted ./userData/binance');
                })
                .catch((err) => {
                    console.error(`Error deleting directory: ${err}`);
                });
        } catch (error) {

        }
        var launchOptions = {
            args: [
                `--proxy-server=${proxyip}:${proxyport}`,
                "--no-sandbox",
                "--disable-infobars",
                // "--window-position=0,0",
                "--deterministic-fetch",
                "--start-maximized",
                "--test-type",
                // `--user-agent="'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36'"`
            ],
            executablePath: chromePath,
            headless: false,
            devtools: false,
            ignoreHTTPSErrors: true,
            defaultViewport: null,
            userDataDir: "userData/binance",
            ignoreDefaultArgs: ["--enable-automation"]
        };
        try {
            var browser = await puppeteer.launch(launchOptions);
            await helper.delay(1000);
            var pages = await browser.pages();
            const numberOfPages = (await browser.pages()).length;
            if (numberOfPages > 1) {
                for (let i = 1; i < numberOfPages; i++) {
                    await pages[i].close();
                    await helper.delay(100);
                }
            }
            var [page] = await browser.pages();
            await helper.delay(1000);
            await page.authenticate({
                username: proxyuser,
                password: proxypass
            });
        } catch (error) {
            await helper.delay(500);
            console.log("Browser failed to open");
            process.exit();
        }
        await page.setDefaultTimeout(90000);
        await page.evaluateOnNewDocument(`navigator.mediaDevices.getUserMedia = navigator.webkitGetUserMedia = navigator.mozGetUserMedia = navigator.getUserMedia = webkitRTCPeerConnection = RTCPeerConnection = MediaStreamTrack = undefined;`);
        await page.setUserAgent(newUserAgent);
        await helper.delay(500);
        await page.goto('https://accounts.binance.com/en/login', { waitUntil: ['networkidle0'] });
        // await page.goto('https://www.whatismyip.com/', { waitUntil: ['networkidle0'] });
        // console.log(proxyip);
        // console.log(proxyport);
        // await helper.delay(100000);
        try {
            // if (await page.$$('button[id="onetrust-accept-btn-handler"]').length > 0) {
            const [acceptCookiesBtn] = await page.$$('button[id="onetrust-accept-btn-handlers"]');
            // console.log(acceptCookiesBtn);
            if (acceptCookiesBtn) {
                await acceptCookiesBtn.click();

                // await helper.delay(2000);
                await helper.delay(500);

            }
            // }
        } catch (error) {

        }
        try {
            const [emailHandle] = await page.$$('input[name="username"]');
            await emailHandle.type(email, { delay: 25 });
            await helper.delay(100);
            try {
                const [checkBox] = await page.$$('div[class="bn-checkbox-icon"]');
                await checkBox.click();
                await helper.delay(100);
            } catch (error) {

            }

            try {
                // if (await page.$$('button[id="onetrust-accept-btn-handler"]').length > 0) {
                const [acceptCookiesBtn] = await page.$$('button[id="onetrust-accept-btn-handler"]');
                if (acceptCookiesBtn) {
                    await acceptCookiesBtn.click();

                    // await helper.delay(2000);
                    await helper.delay(500);

                }
                // }
            } catch (error) {

            }

            const [nextButtonHandle] = await page.$$('button[class="bn-button bn-button__primary data-size-large mt-6"]');
            // const [nextButtonHandle] = await page.$$('button[id="click-registration-submit-v2"]');

            await nextButtonHandle.click();
            try {
                await page.waitForSelector('div[class="bcap-image-cell-image"]', { timeout: 4000 });
            } catch (error) {

            }
            try {
                if (await page.evaluate(`document.querySelectorAll('div[class="bcap-verify-button"]')[0].innerText`) === "Next") {

                    captchaRequired = true;

                    try {
                        var isCaptcha = await page.$$('div[class="bcap-image-cell-image"]');
                        while (isCaptcha.length > 0) {
                            var imageURLRaw = await page.evaluate(`document.querySelectorAll('div[class="bcap-image-cell-image"]')[0].getAttribute('style');`);
                            var imageURL = imageURLRaw.split('"');
                            var textInstructions = await page.evaluate(`document.querySelectorAll('div[class="bcap-text-message-container"]')[0].innerText`);
                            var imageBuffer = await axios.get(imageURL[1], { responseType: 'arraybuffer' });
                            var raw = Buffer.from(imageBuffer.data).toString('base64');
                            var params = {
                                key: '3b0979a6184cf7e279ec5fd3e5a25267',
                                method: 'base64',
                                recaptcha: 1,
                                body: raw,
                                textinstructions: textInstructions.replace('\n', ' '),
                                recaptcharows: 3,
                                recaptchacols: 3
                            };
                            var captchaResponse = await axios.post('https://2captcha.com/in.php', params);
                            var captchaResponseData = await captchaResponse.data;
                            var captchaID = captchaResponseData.split('|')[1];
                            //Second captcha image
                            var imageURLRaw2 = await page.evaluate(`document.querySelectorAll('div[class="bcap-image-table bcap-left-transition page2 rotated"] div[class="bcap-image-cell-image"]')[0].getAttribute('style');`);
                            var imageURL2 = imageURLRaw2.split('"');
                            var imageBuffer2 = await axios.get(imageURL2[1], { responseType: 'arraybuffer' });
                            var raw2 = Buffer.from(imageBuffer2.data).toString('base64');
                            var params2 = {
                                key: '3b0979a6184cf7e279ec5fd3e5a25267',
                                method: 'base64',
                                recaptcha: 1,
                                body: raw2,
                                textinstructions: textInstructions.replace('\n', ' '),
                                recaptcharows: 3,
                                recaptchacols: 3
                            };
                            var captchaResponse2 = await axios.post('https://2captcha.com/in.php', params2);
                            var captchaResponseData2 = await captchaResponse2.data;
                            var captchaID2 = captchaResponseData2.split('|')[1];
                            try {
                                var captchaSolvedResponse = await axios.get(`https://2captcha.com/res.php?key=3b0979a6184cf7e279ec5fd3e5a25267&action=get&id=${captchaID}`);
                                var captchaSolvedResponseData = await captchaSolvedResponse.data;
                                while (captchaSolvedResponseData === "CAPCHA_NOT_READY") {
                                    console.log(`Waiting to solve captcha...`);
                                    await helper.delay(7000);
                                    var captchaSolvedResponse = await axios.get(`https://2captcha.com/res.php?key=3b0979a6184cf7e279ec5fd3e5a25267&action=get&id=${captchaID}`);
                                    var captchaSolvedResponseData = await captchaSolvedResponse.data;
                                }
                                var selectGrids = captchaSolvedResponseData.split('|')[1].split(':')[1].split('/');
                                for (selection of selectGrids) {
                                    // await page.evaluate(`document.querySelectorAll('div[class="bcap-image-cell-image"]')[${selection - 1}].click()`);
                                    await page.evaluate(`document.querySelectorAll('div[class="bcap-image-cell-image"]')[${selection - 1}].click()`);
                                    await helper.delay(1000);
                                }
                                var [verifyBtn] = await page.$$('div[class="bcap-verify-button"]');
                                await verifyBtn.click();
                                await helper.delay(1000);
                            } catch (error) {
                                console.log(error);
                            }
                            try {
                                var captchaSolvedResponse = await axios.get(`https://2captcha.com/res.php?key=3b0979a6184cf7e279ec5fd3e5a25267&action=get&id=${captchaID2}`);
                                var captchaSolvedResponseData = await captchaSolvedResponse.data;
                                while (captchaSolvedResponseData === "CAPCHA_NOT_READY") {
                                    console.log(`Waiting to solve captcha2...`);
                                    await helper.delay(7000);
                                    var captchaSolvedResponse = await axios.get(`https://2captcha.com/res.php?key=3b0979a6184cf7e279ec5fd3e5a25267&action=get&id=${captchaID2}`);
                                    var captchaSolvedResponseData = await captchaSolvedResponse.data;
                                }
                                var selectGrids = captchaSolvedResponseData.split('|')[1].split(':')[1].split('/');
                                for (selection of selectGrids) {
                                    // await page.evaluate(`document.querySelectorAll('div[class="bcap-image-cell-image"]')[${selection - 1}].click()`);
                                    await page.evaluate(`document.querySelectorAll('div[class="bcap-image-table bcap-left-transition page2 rotated"] div[class="bcap-image-cell-image"]')[${selection - 1}].click()`);
                                    await helper.delay(1000);
                                }
                                var [verifyBtn] = await page.$$('div[class="bcap-verify-button"]');
                                await verifyBtn.click();
                            } catch (error) {
                                console.log(error);
                            }

                        }
                    } catch (error) {

                    }
                } else if (await page.evaluate(`document.querySelectorAll('div[class="bcap-verify-button"]')[0].innerText`) === "Verify") {
                    await page.waitForSelector('div[class="bcap-image-cell-image"]', { timeout: 4000 });

                    captchaRequired = true;

                    try {
                        var isCaptcha = await page.$$('div[class="bcap-image-cell-image"]');
                        while (isCaptcha.length > 0) {
                            console.log('Captcha Request Sent');
                            fs.appendFileSync(captchaRequest, `Captcha Request Sent\n`);
                            var imageURLRaw = await page.evaluate(`document.querySelectorAll('div[class="bcap-image-cell-image"]')[0].getAttribute('style');`);
                            const imageURL = imageURLRaw.split('"');
                            // console.log(imageURL);
                            const textInstructions = await page.evaluate(`document.querySelectorAll('div[class="bcap-text-message-container"]')[0].innerText`);
                            // console.log(textInstructions);
                            const imageBuffer = await axios.get(imageURL[1], { responseType: 'arraybuffer' });
                            const raw = Buffer.from(imageBuffer.data).toString('base64');
                            const params = {
                                key: '3b0979a6184cf7e279ec5fd3e5a25267',
                                method: 'base64',
                                recaptcha: 1,
                                body: raw,
                                textinstructions: textInstructions.replace('\n', ' '),
                                recaptcharows: 3,
                                recaptchacols: 3
                            };
                            try {
                                const captchaResponse = await axios.post('https://2captcha.com/in.php', params);
                                // console.log(captchaResponse);
                                const captchaResponseData = await captchaResponse.data;
                                const captchaID = captchaResponseData.split('|');
                                var captchaSolvedResponse = await axios.get(`https://2captcha.com/res.php?key=3b0979a6184cf7e279ec5fd3e5a25267&action=get&id=${captchaID[1]}`);
                                var captchaSolvedResponseData = await captchaSolvedResponse.data;

                                // new
                                // await helper.delay(2000);

                                while (captchaSolvedResponseData === "CAPCHA_NOT_READY") {
                                    console.log(`Waiting to solve captcha...`);
                                    await helper.delay(7000);
                                    var captchaSolvedResponse = await axios.get(`https://2captcha.com/res.php?key=3b0979a6184cf7e279ec5fd3e5a25267&action=get&id=${captchaID[1]}`);
                                    var captchaSolvedResponseData = await captchaSolvedResponse.data;
                                }
                                const selectGrids = captchaSolvedResponseData.split('|')[1].split(':')[1].split('/');
                                for (selection of selectGrids) {
                                    // await page.evaluate(`document.querySelectorAll('div[class="bcap-image-cell-image"]')[${selection - 1}].click()`);
                                    // console.log('clicked');
                                    await page.evaluate(`document.querySelectorAll('div[class="bcap-image-cell-image"]')[${selection - 1}].click()`);
                                    await helper.delay(1000);
                                }
                                const [verifyBtn] = await page.$$('div[class="bcap-verify-button"]');
                                await verifyBtn.click();

                                // await helper.delay(7000);
                                await helper.delay(4000);

                                try {
                                    var isCaptcha = await page.$$('div[class="bcap-image-cell-image"]');
                                } catch (error) {

                                }
                            } catch (error) {
                                console.log(error);
                            }
                        }
                    } catch (error) {

                    }
                }
            } catch (error) {

            }
        } catch (error) {
            console.log(error);
        }

        await helper.delay(5000);
        // await helper.delay(2000);

        // let errorExists = false;

        if (await page.evaluate(`document.body.innerText.includes("Binance account not found.")`)) {
            fs.appendFileSync(results, `${email} | Account doesn't exist | on proxy : ${proxyip}:${proxyport} | captcha required : ${captchaRequired ? `yes` : `no`}\n`);
            await helper.delay(500);
        } else if (await page.evaluate(`document.querySelectorAll('[name="password"]').length`) > 0) {
            fs.appendFileSync(results, `${email} | Account exists | on proxy : ${proxyip}:${proxyport} | captcha required : ${captchaRequired ? `yes` : `no`}\n`);
            await helper.delay(500);
        } else {
            fs.appendFileSync(results, `${email} | Error on webpage | on proxy : ${proxyip}:${proxyport} | captcha required : ${captchaRequired ? `yes` : `no`}\n`);
            // errorExists = true;
            await helper.delay(500);
        }
        // if (!errorExists) {
        //     // Delete the first email from binance-emails.txt
        //     // console.log(`checked email : ${email}`);
        //     const emailsListUpdate = await fs.readFileSync(emails).toString().split('\r\n');
        //     try {
        //         const [firstEmail, ...remainingEmails] = emailsListUpdate;
        //         fs.writeFileSync(emails, remainingEmails.join('\r\n'));
        //         // console.log(`Deleted email: ${firstEmail}`);
        //     } catch (error) {
        //         console.error(`Error deleting first email from binance-emails.txt:`, error);
        //     }
        // }
        // Delete the first email from binance-emails.txt
        // console.log(`checked email : ${email}`);
        const emailsListUpdate = await fs.readFileSync(emails).toString().split('\r\n');
        try {
            const [firstEmail, ...remainingEmails] = emailsListUpdate;
            fs.writeFileSync(emails, remainingEmails.join('\r\n'));
            // console.log(`Deleted email: ${firstEmail}`);
        } catch (error) {
            console.error(`Error deleting first email from binance-emails.txt:`, error);
        }
        await browser.close();
        await helper.delay(100);
        try {
            if (await browser.isConnected()) {
                await browser.close();
                await helper.delay(100);
            }
        } catch (error) {

        }
        // console.log(rimraf);
        rimraf('./userData/binance')
            .then(() => {
                console.log('Deleted ./userData/binance');
            })
            .catch((err) => {
                console.error(`Error deleting directory: ${err}`);
            });
    }


})();

async function getProxy(proxyIndex) {
    // const webshareToken = 'eo94ganz9l0xizty9815fowcq7d7gnr0fseecvj6'; // Personal
    const webshareToken = '1m0a6elnrjjgmfnui9a6rs7imotxfi3smi754i8f'; // All
    const webshareAPI = "https://proxy.webshare.io/api/v2/proxy/list/?mode=direct&page=1&page_size=25";
    const apiResponse = await axios.get(webshareAPI, {
        headers: {
            Authorization: "Token " + webshareToken
        }
    })
    const apiData = await apiResponse.data;
    // console.log(apiData.results.length);
    return apiData.results[proxyIndex];
}


// async function getProxy(proxyIndex) {
//     // console.log(proxyIndex);
//     const filePath = path.join(__dirname, 'proxies.txt');

//     try {
//         const data = fs.readFileSync(filePath, 'utf8');

//         const proxies = data.trim().split('\n');

//         if (proxyIndex < 0 || proxyIndex >= proxies.length) {
//             throw new Error('Proxy index out of range');
//         }

//         const proxy = proxies[proxyIndex];

//         const [proxy_address, port, username, password] = proxy.split(':');

//         const proxyData = {
//             proxy_address,
//             port: parseInt(port, 10),
//             username,
//             password
//         };

//         // console.log(proxyData);
//         return proxyData;

//     } catch (error) {
//         console.error('Error reading proxy data:', error);
//     }
// }