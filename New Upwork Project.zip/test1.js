const fs = require('fs');
const path = require('path');

async function getProxy(proxyIndex) {
    const filePath = path.join(__dirname, 'proxies.txt');

    try {
        // Read the proxies file
        const data = fs.readFileSync(filePath, 'utf8');

        // Split the data by new lines to get each proxy entry
        const proxies = data.trim().split('\n');

        // Check if the proxyIndex is within range
        if (proxyIndex < 0 || proxyIndex >= proxies.length) {
            throw new Error('Proxy index out of range');
        }

        // Get the proxy at the given index
        const proxy = proxies[proxyIndex];

        // Split the proxy entry to extract its components
        const [proxy_address, port, username, password] = proxy.split(':');

        // Construct the proxy object
        const proxyData = {
            proxy_address,
            port: parseInt(port, 10),
            username,
            password
        };

        console.log(proxyData);
        return proxyData;

    } catch (error) {
        console.error('Error reading proxy data:', error);
    }
}

// Example usage
const proxyIndex = 0; // Change this to the desired index
getProxy(proxyIndex);
