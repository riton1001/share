const axios = require('axios');

const captchaResponseData = "OK|76477491593";

const captchaID = captchaResponseData.split('|');

// console.log(captchaID[1]);

const data = async() => {
    var captchaSolvedResponse = await axios.get(`https://2captcha.com/res.php?key=3b0979a6184cf7e279ec5fd3e5a25267&action=get&id=${captchaID[1]}`);
    console.log(captchaSolvedResponse);
    return captchaSolvedResponse;
}

data();